#ifndef PE12_2A_H
#define PE12_2A_H

#include <stdio.h>
static int mode = 0;
static double distance = 0;
static double fuel_consumed = 0;

void set_mode(int set);
void get_info(void);
void show_info(void);

#endif // !PE12-2A_H
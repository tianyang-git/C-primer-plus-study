#if 0
#include <stdio.h>

int main(void)
{
	int num = 10;
	printf("The variable num = %d.\n", num);
	printf("double num = %d.\n", num * 2);
	printf("num square = %d.\n", num*num);

	return 0;
}

#endif
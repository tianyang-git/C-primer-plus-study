#if 0
#include <stdio.h>

int main(void)
{
	printf("Stephen chow\n");
	printf("No.128 Queens road, HK\n");

	return 0;
}

#endif
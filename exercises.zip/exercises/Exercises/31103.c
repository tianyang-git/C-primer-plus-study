#if 0
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	printf("\a");
	printf("Startled by the sudden sound, Sally shouted,\n");
	printf("\"By the Great Pumpkin, what was that!\"");
	return 0;
}

#endif
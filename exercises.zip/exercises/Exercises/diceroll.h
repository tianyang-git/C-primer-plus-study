#ifndef DICEROLL_H
#define DICEROLL_H

extern int roll_count;
int roll_n_dice(int dice, int sides);

#endif // !DICEROLL_H
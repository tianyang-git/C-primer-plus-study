#ifndef PE12_3A_H
#define PE12_3A_H

#include <stdio.h>

void set_mode3a(int * mode);
void get_info3a(int mode, double *distance, double *fuel);
void show_info3a(int mode, double distance, double fuel);

#endif // !PE12_3A_H
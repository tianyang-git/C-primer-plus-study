#if 0
#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	int num = 0;
	printf("Enter a value of char integer ASCII:");
	scanf_s("%d", &num);
	printf("You input value is %d, and character is %c\n", num, num);

	return 0;
}

#endif